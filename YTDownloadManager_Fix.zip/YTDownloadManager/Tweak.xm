#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import <Photos/Photos.h>
#import <objc/runtime.h>

static char kAssociatedOutURLKey;
static NSString *const kYTDMQueueUpdatedNotification = @"YTDMQueueUpdatedNotification";

static NSString *qVideo1080 = nil;
static NSString *qVideo720 = nil;
static NSString *qVideo480 = nil;
static NSString *qVideo360 = nil;
static NSString *qVideo240 = nil;
static NSString *qVideo144 = nil;
static NSString *qAudio = nil;

// ============================================================================
// FORWARD DECLARATIONS & QUEUE ENGINE INTERFACES
// ============================================================================
typedef NS_ENUM(NSInteger, YTDMQueueStatus) {
    YTDMQueueStatusPending,
    YTDMQueueStatusDownloading,
    YTDMQueueStatusDownloaded,
    YTDMQueueStatusError
};

@interface YTDMQueueItem : NSObject
@property (nonatomic, copy) NSString *videoId;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *quality;
@property (nonatomic, assign) BOOL isAudio;
@property (nonatomic, assign) YTDMQueueStatus status;
@property (nonatomic, assign) float progress;
@property (nonatomic, copy) NSString *jobId;
@property (nonatomic, strong) NSArray<NSURL *> *localURLs;
@property (nonatomic, assign) NSInteger pollRetryCount;
- (instancetype)initWithDictionary:(NSDictionary *)dict;
- (NSDictionary *)toDictionary;
@end

@interface YTDMQueueManager : NSObject
@property (nonatomic, strong) NSMutableArray<YTDMQueueItem *> *videoQueue;
@property (nonatomic, strong) NSMutableArray<YTDMQueueItem *> *audioQueue;
@property (nonatomic, assign) BOOL isProcessingVideo;
@property (nonatomic, assign) BOOL isProcessingAudio;
+ (instancetype)sharedManager;
- (void)addItemWithId:(NSString *)vId title:(NSString *)title quality:(NSString *)quality isAudio:(BOOL)isAudio;
- (void)saveQueueToDisk;
- (void)loadQueueFromDisk;
- (void)startDownloadingQueue:(BOOL)isAudio;
- (void)cancelItem:(YTDMQueueItem *)item;
- (void)retryItem:(YTDMQueueItem *)item;
@end

@interface YTDMQueueSheetController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITableViewDragDelegate, UITableViewDropDelegate, UIDocumentPickerDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UISegmentedControl *segmentedControl;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIButton *downloadAllButton;
@end

static UIWindow *getKeyWindow(void) {
    UIWindow *keyWindow = nil;
    for (UIScene *scene in [UIApplication sharedApplication].connectedScenes) {
        if ([scene isKindOfClass:[UIWindowScene class]] && scene.activationState == UISceneActivationStateForegroundActive) {
            for (UIWindow *window in [(UIWindowScene *)scene windows]) {
                if (window.isKeyWindow) { keyWindow = window; break; }
            }
        }
        if (keyWindow) break;
    }
    if (!keyWindow) {
        for (UIWindow *window in [UIApplication sharedApplication].windows) {
            if (window.isKeyWindow) { keyWindow = window; break; }
        }
    }
    if (!keyWindow) keyWindow = [UIApplication sharedApplication].windows.firstObject;
    return keyWindow;
}

static UIViewController *getTopMostController(void) {
    UIWindow *window = getKeyWindow();
    UIViewController *root = window.rootViewController;
    while (root.presentedViewController) { root = root.presentedViewController; }
    return root;
}

// ============================================================================
// ANIMATED PROGRESS HUD
// ============================================================================
@interface YTDMProgressHUD : UIView
@property (nonatomic, strong) UIVisualEffectView *blurView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIProgressView *progressView;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UILabel *feedbackIconLabel;
+ (instancetype)sharedHUD;
- (void)showInView:(UIView *)parentView;
- (void)updateProgress:(float)progress status:(NSString *)status;
- (void)showSuccessWithStatus:(NSString *)status;
- (void)showError:(NSString *)errorMessage;
- (void)dismiss;
@end

@implementation YTDMProgressHUD
+ (instancetype)sharedHUD {
    static YTDMProgressHUD *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [[self alloc] initWithFrame:CGRectMake(0, 0, 240, 170)]; });
    return shared;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 18;
        self.layer.masksToBounds = YES;
        
        UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
        _blurView.frame = self.bounds;
        [self addSubview:_blurView];
        
        _spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleLarge];
        _spinner.color = [UIColor whiteColor];
        _spinner.center = CGPointMake(frame.size.width / 2, 45);
        [_blurView.contentView addSubview:_spinner];

        _feedbackIconLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 15, frame.size.width, 60)];
        _feedbackIconLabel.textColor = [UIColor whiteColor];
        _feedbackIconLabel.font = [UIFont systemFontOfSize:50 weight:UIFontWeightMedium];
        _feedbackIconLabel.textAlignment = NSTextAlignmentCenter;
        _feedbackIconLabel.hidden = YES;
        [_blurView.contentView addSubview:_feedbackIconLabel];
        
        _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 85, frame.size.width - 20, 20)];
        _titleLabel.text = @"YTDM Suite";
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.font = [UIFont boldSystemFontOfSize:15];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        [_blurView.contentView addSubview:_titleLabel];
        
        _progressView = [[UIProgressView alloc] initWithProgressViewStyle:UIProgressViewStyleDefault];
        _progressView.frame = CGRectMake(25, 115, frame.size.width - 50, 4);
        _progressView.progressTintColor = [UIColor systemGreenColor];
        _progressView.trackTintColor = [[UIColor whiteColor] colorWithAlphaComponent:0.2];
        _progressView.hidden = YES;
        [_blurView.contentView addSubview:_progressView];
        
        _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 122, frame.size.width - 20, 38)];
        _statusLabel.text = @"Connecting...";
        _statusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.85];
        _statusLabel.font = [UIFont systemFontOfSize:12];
        _statusLabel.textAlignment = NSTextAlignmentCenter;
        _statusLabel.numberOfLines = 2;
        [_blurView.contentView addSubview:_statusLabel];
    }
    return self;
}

- (void)showInView:(UIView *)parentView {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.alpha = 0.0;
        self.center = CGPointMake(parentView.bounds.size.width / 2, parentView.bounds.size.height / 2);
        [parentView addSubview:self];
        [parentView bringSubviewToFront:self];
        
        self.progressView.progress = 0.0;
        self.progressView.hidden = YES;
        self.feedbackIconLabel.hidden = YES;
        self.spinner.hidden = NO;
        [self.spinner startAnimating];
        self.statusLabel.text = @"Contacting the server...";
        
        [UIView animateWithDuration:0.25 animations:^{ self.alpha = 1.0; }];
    });
}

- (void)updateProgress:(float)progress status:(NSString *)status {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (progress >= 0.0) {
            self.spinner.hidden = YES;
            [self.spinner stopAnimating];
            self.progressView.hidden = NO;
            self.progressView.progress = progress;
        }
        if (status) self.statusLabel.text = status;
    });
}

- (void)showSuccessWithStatus:(NSString *)status {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.alpha = 1.0;
        if (!self.superview) {
            [getKeyWindow() addSubview:self];
            [getKeyWindow() bringSubviewToFront:self];
            self.center = CGPointMake(getKeyWindow().bounds.size.width / 2, getKeyWindow().bounds.size.height / 2);
        }
        self.spinner.hidden = YES;
        [self.spinner stopAnimating];
        self.progressView.hidden = YES;
        self.feedbackIconLabel.text = @"✓";
        self.feedbackIconLabel.textColor = [UIColor systemGreenColor];
        self.feedbackIconLabel.hidden = NO;
        if (status) self.statusLabel.text = status;
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self dismiss]; });
    });
}

- (void)showError:(NSString *)errorMessage {
    dispatch_async(dispatch_get_main_queue(), ^{
        self.alpha = 1.0;
        if (!self.superview) {
            [getKeyWindow() addSubview:self];
            [getKeyWindow() bringSubviewToFront:self];
            self.center = CGPointMake(getKeyWindow().bounds.size.width / 2, getKeyWindow().bounds.size.height / 2);
        }
        self.spinner.hidden = YES;
        [self.spinner stopAnimating];
        self.progressView.hidden = YES;
        self.feedbackIconLabel.text = @"✗";
        self.feedbackIconLabel.textColor = [UIColor systemRedColor];
        self.feedbackIconLabel.hidden = NO;
        self.statusLabel.text = errorMessage ?: @"Error occurred.";
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self dismiss]; });
    });
}

- (void)dismiss {
    [UIView animateWithDuration:0.25 animations:^{ self.alpha = 0.0; } completion:^(BOOL finished) { [self removeFromSuperview]; }];
}
@end

// ============================================================================
// SERVER COMMUNICATION SERVICE
// ============================================================================
@interface YTDownloadManagerService : NSObject
+ (instancetype)sharedInstance;
- (NSString *)serverEndpoint;
- (void)requestDownloadForVideoId:(NSString *)vId isAudio:(BOOL)isAudio quality:(NSString *)quality completion:(void (^)(NSArray<NSURL *> *localURLs, NSString *errorMsg))completionBlock;
- (void)requestStreamURLForVideoId:(NSString *)vId completion:(void (^)(NSString *streamURL, NSString *errorMsg))completionBlock;
@end

@implementation YTDownloadManagerService
+ (instancetype)sharedInstance {
    static YTDownloadManagerService *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [[self alloc] init]; });
    return shared;
}

- (NSString *)serverEndpoint {
    return @"https://waterdl.freeddns.org/"
}

- (void)requestDownloadForVideoId:(NSString *)vId isAudio:(BOOL)isAudio quality:(NSString *)quality completion:(void (^)(NSArray<NSURL *> *localURLs, NSString *errorMsg))completionBlock {
    NSString *watchURL = [NSString stringWithFormat:@"https://www.youtube.com/watch?v=%@", vId];
    [self startYTDMDownloadWithWatchURL:watchURL format:isAudio ? @"audio" : @"video" formatId:quality completion:completionBlock];
}

- (void)requestStreamURLForVideoId:(NSString *)vId completion:(void (^)(NSString *streamURL, NSString *errorMsg))completionBlock {
    NSString *urlStr = [[self serverEndpoint] stringByAppendingString:@"api/stream"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSDictionary *payload = @{@"url": [NSString stringWithFormat:@"https://www.youtube.com/watch?v=%@", vId]};
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error || !data) { completionBlock(nil, @"Stream Connection Error"); return; }
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if (json[@"stream_url"]) completionBlock(json[@"stream_url"], nil);
        else completionBlock(nil, json[@"error"] ?: @"Stream failed");
    }] resume];
}

- (void)startYTDMDownloadWithWatchURL:(NSString *)watchURL format:(NSString *)format formatId:(NSString *)formatId completion:(void (^)(NSArray<NSURL *> *localURLs, NSString *errorMsg))completionBlock {
    NSString *urlStr = [[self serverEndpoint] stringByAppendingString:@"api/download"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSMutableDictionary *payload = [@{@"url": watchURL, @"format": format} mutableCopy];
    if (formatId) payload[@"format_id"] = formatId;
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error || !data) { completionBlock(nil, @"Server unreachable."); return; }
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if (json[@"job_id"]) [self pollJobStatus:json[@"job_id"] completion:completionBlock];
        else completionBlock(nil, json[@"error"] ?: @"Job init failed.");
    }] resume];
}

- (void)pollJobStatus:(NSString *)jobId completion:(void (^)(NSArray<NSURL *> *localURLs, NSString *errorMsg))completionBlock {
    NSString *urlStr = [NSString stringWithFormat:@"%@api/status/%@", [self serverEndpoint], jobId];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (error || !data) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self pollJobStatus:jobId completion:completionBlock]; });
            return;
        }
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSString *status = json[@"status"];
        
        if ([status isEqualToString:@"done"]) {
            id filesData = json[@"files"] ?: json[@"filenames"] ?: json[@"filename"] ?: json[@"file_path"];
            NSMutableArray<NSString *> *filesToDownload = [NSMutableArray array];
            
            if ([filesData isKindOfClass:[NSArray class]]) {
                for (id fileItem in filesData) {
                    if ([fileItem isKindOfClass:[NSString class]]) [filesToDownload addObject:[fileItem lastPathComponent]];
                }
            } else if ([filesData isKindOfClass:[NSString class]]) {
                [filesToDownload addObject:[filesData lastPathComponent]];
            }
            
            if (filesToDownload.count == 0) {
                completionBlock(nil, @"No files found in job.");
                return;
            }
            [self downloadMultipleFiles:filesToDownload forJobId:jobId completion:completionBlock];
        } else if ([status isEqualToString:@"error"]) {
            completionBlock(nil, json[@"error"] ?: @"Server Error.");
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{ [[YTDMProgressHUD sharedHUD] updateProgress:-1.0 status:@"Downloading on the server..."]; });
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self pollJobStatus:jobId completion:completionBlock]; });
        }
    }] resume];
}

- (void)downloadMultipleFiles:(NSArray<NSString *> *)filenames forJobId:(NSString *)jobId completion:(void (^)(NSArray<NSURL *> *localURLs, NSString *errorMsg))completionBlock {
    NSMutableArray<NSURL *> *localURLs = [NSMutableArray array];
    __block NSInteger remaining = filenames.count;
    __block NSString *errStr = nil;
    NSInteger totalCount = filenames.count;
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[YTDMProgressHUD sharedHUD] updateProgress:0.0 status:[NSString stringWithFormat:@"Syncing files: 0/%lu", (unsigned long)totalCount]];
    });

    for (NSString *filename in filenames) {
        NSString *encodedName = [filename stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        NSString *urlString = [NSString stringWithFormat:@"%@api/file/%@?filename=%@", [self serverEndpoint], jobId, encodedName];
        
        [[[NSURLSession sharedSession] downloadTaskWithURL:[NSURL URLWithString:urlString] completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
            if (error || !location) {
                errStr = error.localizedDescription;
            } else {
                NSString *tempDir = NSTemporaryDirectory();
                NSURL *destURL = [NSURL fileURLWithPath:[tempDir stringByAppendingPathComponent:filename]];
                [[NSFileManager defaultManager] removeItemAtURL:destURL error:nil];
                
                if ([[NSFileManager defaultManager] moveItemAtURL:location toURL:destURL error:nil]) {
                    @synchronized(localURLs) { [localURLs addObject:destURL]; }
                }
            }
            
            @synchronized(self) {
                remaining--;
                float progress = (float)(totalCount - remaining) / (float)totalCount;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[YTDMProgressHUD sharedHUD] updateProgress:progress status:[NSString stringWithFormat:@"Syncing files: %lu/%lu", (unsigned long)(totalCount - remaining), (unsigned long)totalCount]];
                });
                
                if (remaining == 0) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (localURLs.count > 0) completionBlock(localURLs, nil);
                        else completionBlock(nil, errStr ?: @"Download sync failed.");
                    });
                }
            }
        }] resume];
    }
}
@end

// ============================================================================
// CORE SMART DOWNLOAD QUEUE ENGINE BACKEND
// ============================================================================
@implementation YTDMQueueItem
- (instancetype)initWithDictionary:(NSDictionary *)dict {
    self = [super init];
    if (self) {
        _videoId = [dict[@"videoId"] copy];
        _title = [dict[@"title"] copy];
        _quality = [dict[@"quality"] copy];
        _isAudio = [dict[@"isAudio"] boolValue];
        _status = (YTDMQueueStatus)[dict[@"status"] integerValue];
        _progress = [dict[@"progress"] floatValue];
        _jobId = [dict[@"jobId"] copy];
        _pollRetryCount = 0;
        
        if (_status == YTDMQueueStatusDownloading) {
            _status = YTDMQueueStatusPending;
            _progress = 0.0;
        }
        
        NSArray *fileNames = dict[@"localFileNames"];
        if (fileNames && fileNames.count > 0) {
            NSMutableArray *urls = [NSMutableArray array];
            NSString *cacheDir = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
            BOOL allFilesExist = YES;
            for (NSString *name in fileNames) {
                NSString *fullPath = [cacheDir stringByAppendingPathComponent:name];
                if ([[NSFileManager defaultManager] fileExistsAtPath:fullPath]) {
                    [urls addObject:[NSURL fileURLWithPath:fullPath]];
                } else {
                    allFilesExist = NO; break;
                }
            }
            if (allFilesExist && urls.count > 0) _localURLs = [urls copy];
            else { _status = YTDMQueueStatusError; _progress = 0.0; _localURLs = nil; }
        }
    }
    return self;
}

- (NSDictionary *)toDictionary {
    NSMutableArray *fileNames = [NSMutableArray array];
    for (NSURL *u in _localURLs) { if (u.lastPathComponent) [fileNames addObject:u.lastPathComponent]; }
    return @{
        @"videoId": _videoId ?: @"",
        @"title": _title ?: @"",
        @"quality": _quality ?: @"",
        @"isAudio": @(_isAudio),
        @"status": @(_status),
        @"progress": @(_progress),
        @"jobId": _jobId ?: @"",
        @"localFileNames": fileNames
    };
}
@end

@implementation YTDMQueueManager
+ (instancetype)sharedManager {
    static YTDMQueueManager *shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ shared = [[self alloc] init]; [shared loadQueueFromDisk]; });
    return shared;
}

- (instancetype)init {
    self = [super init];
    if (self) { _videoQueue = [NSMutableArray array]; _audioQueue = [NSMutableArray array]; }
    return self;
}

- (NSString *)queueFilePath {
    NSString *appSupportDir = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES).firstObject;
    NSString *ytdmDir = [appSupportDir stringByAppendingPathComponent:@"YTDM"];
    [[NSFileManager defaultManager] createDirectoryAtPath:ytdmDir withIntermediateDirectories:YES attributes:nil error:nil];
    return [ytdmDir stringByAppendingPathComponent:@"ytdm_persistent_queue.json"];
}

- (void)postSafeUpdateNotification {
    dispatch_async(dispatch_get_main_queue(), ^{ [[NSNotificationCenter defaultCenter] postNotificationName:kYTDMQueueUpdatedNotification object:nil]; });
}

- (void)saveQueueToDisk {
    NSMutableArray *vArr = [NSMutableArray array];
    for (YTDMQueueItem *i in _videoQueue) [vArr addObject:[i toDictionary]];
    NSMutableArray *aArr = [NSMutableArray array];
    for (YTDMQueueItem *i in _audioQueue) [aArr addObject:[i toDictionary]];
    
    NSData *data = [NSJSONSerialization dataWithJSONObject:@{@"video": vArr, @"audio": aArr} options:0 error:nil];
    if (data) [data writeToFile:[self queueFilePath] atomically:YES];
}

- (void)loadQueueFromDisk {
    NSData *data = [NSData dataWithContentsOfFile:[self queueFilePath]];
    if (!data) return;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
    if (!dict || ![dict isKindOfClass:[NSDictionary class]]) return;
    
    [_videoQueue removeAllObjects]; [_audioQueue removeAllObjects];
    if ([dict[@"video"] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *i in dict[@"video"]) [_videoQueue addObject:[[YTDMQueueItem alloc] initWithDictionary:i]];
    }
    if ([dict[@"audio"] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *i in dict[@"audio"]) [_audioQueue addObject:[[YTDMQueueItem alloc] initWithDictionary:i]];
    }
}

- (void)addItemWithId:(NSString *)vId title:(NSString *)title quality:(NSString *)quality isAudio:(BOOL)isAudio {
    NSMutableArray<YTDMQueueItem *> *targetQueue = isAudio ? _audioQueue : _videoQueue;
    for (YTDMQueueItem *existingItem in targetQueue) {
        BOOL sameQuality = (!existingItem.quality && !quality) || (existingItem.quality && [existingItem.quality isEqualToString:quality]);
        if ([existingItem.videoId isEqualToString:vId] && sameQuality && existingItem.isAudio == isAudio) return;
    }

    YTDMQueueItem *item = [[YTDMQueueItem alloc] init];
    item.videoId = vId; item.title = title; item.quality = quality; item.isAudio = isAudio;
    item.status = YTDMQueueStatusPending; item.progress = 0.0;
    
    [targetQueue addObject:item];
    [self saveQueueToDisk]; [self postSafeUpdateNotification];
}

- (void)cancelItem:(YTDMQueueItem *)item {
    if (item.status == YTDMQueueStatusDownloading && item.jobId) {
        NSString *urlStr = [NSString stringWithFormat:@"%@api/cancel/%@", [[YTDownloadManagerService sharedInstance] serverEndpoint], item.jobId];
        NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
        [req setHTTPMethod:@"POST"]; [[[NSURLSession sharedSession] dataTaskWithRequest:req] resume];
    }
    if (item.localURLs) { for (NSURL *u in item.localURLs) [[NSFileManager defaultManager] removeItemAtURL:u error:nil]; }
    if (item.isAudio) [_audioQueue removeObject:item]; else [_videoQueue removeObject:item];
    [self saveQueueToDisk]; [self postSafeUpdateNotification];
}

- (void)retryItem:(YTDMQueueItem *)item {
    item.status = YTDMQueueStatusPending; item.progress = 0.0; item.pollRetryCount = 0;
    [self saveQueueToDisk]; [self postSafeUpdateNotification];
    [self startDownloadingQueue:item.isAudio];
}

- (void)startDownloadingQueue:(BOOL)isAudio {
    if (isAudio && _isProcessingAudio) return;
    if (!isAudio && _isProcessingVideo) return;
    if (isAudio) _isProcessingAudio = YES; else _isProcessingVideo = YES;
    [self processNextItemInQueue:isAudio];
}

- (void)processNextItemInQueue:(BOOL)isAudio {
    NSMutableArray<YTDMQueueItem *> *queue = isAudio ? _audioQueue : _videoQueue;
    __block YTDMQueueItem *targetItem = nil;
    for (YTDMQueueItem *i in queue) { if (i.status == YTDMQueueStatusPending) { targetItem = i; break; } }
    if (!targetItem) { if (isAudio) _isProcessingAudio = NO; else _isProcessingVideo = NO; return; }
    
    targetItem.status = YTDMQueueStatusDownloading;
    [self saveQueueToDisk]; [self postSafeUpdateNotification];
    
    NSString *watchURL = [NSString stringWithFormat:@"https://www.youtube.com/watch?v=%@", targetItem.videoId];
    NSString *urlStr = [[[YTDownloadManagerService sharedInstance] serverEndpoint] stringByAppendingString:@"api/download"];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:urlStr]];
    [request setHTTPMethod:@"POST"]; [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    NSMutableDictionary *payload = [@{@"url": watchURL, @"format": isAudio ? @"audio" : @"video"} mutableCopy];
    if (targetItem.quality) payload[@"format_id"] = targetItem.quality;
    request.HTTPBody = [NSJSONSerialization dataWithJSONObject:payload options:0 error:nil];
    
    [[[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        if (error || !data || (httpResponse && httpResponse.statusCode != 200)) { [self handleItemFailure:targetItem isAudio:isAudio]; return; }
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        if (json && json[@"job_id"]) {
            targetItem.jobId = json[@"job_id"]; targetItem.pollRetryCount = 0;
            [self saveQueueToDisk]; [self pollQueueJobStatus:targetItem isAudio:isAudio];
        } else { [self handleItemFailure:targetItem isAudio:isAudio]; }
    }] resume];
}

- (void)pollQueueJobStatus:(YTDMQueueItem *)item isAudio:(BOOL)isAudio {
    if (item.status != YTDMQueueStatusDownloading) return;
    if (item.pollRetryCount > 30) { [self handleItemFailure:item isAudio:isAudio]; return; }
    
    NSString *urlStr = [NSString stringWithFormat:@"%@api/status/%@", [[YTDownloadManagerService sharedInstance] serverEndpoint], item.jobId];
    [[[NSURLSession sharedSession] dataTaskWithURL:[NSURL URLWithString:urlStr] completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        if (error || !data || (httpResponse && httpResponse.statusCode != 200)) {
            item.pollRetryCount++;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self pollQueueJobStatus:item isAudio:isAudio]; });
            return;
        }
        
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        NSString *status = json[@"status"];
        if ([status isEqualToString:@"done"]) {
            item.pollRetryCount = 0;
            id filesData = json[@"files"] ?: json[@"filenames"] ?: json[@"filename"] ?: json[@"file_path"];
            NSMutableArray<NSString *> *filesToDownload = [NSMutableArray array];
            if ([filesData isKindOfClass:[NSArray class]]) {
                for (id f in filesData) { if ([f isKindOfClass:[NSString class]]) [filesToDownload addObject:[f lastPathComponent]]; }
            } else if ([filesData isKindOfClass:[NSString class]]) {
                [filesToDownload addObject:[filesData lastPathComponent]];
            }
            if (filesToDownload.count == 0) { [self handleItemFailure:item isAudio:isAudio]; return; }
            [self syncQueueFiles:filesToDownload forItem:item isAudio:isAudio];
        } else if ([status isEqualToString:@"processing"] || [status isEqualToString:@"downloading"] || [status isEqualToString:@"pending"]) {
            item.pollRetryCount = 0;
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{ [self pollQueueJobStatus:item isAudio:isAudio]; });
        } else { [self handleItemFailure:item isAudio:isAudio]; }
    }] resume];
}

- (void)syncQueueFiles:(NSArray<NSString *> *)filenames forItem:(YTDMQueueItem *)item isAudio:(BOOL)isAudio {
    NSMutableArray<NSURL *> *localURLs = [NSMutableArray array];
    __block NSInteger remaining = filenames.count; __block BOOL subFailed = NO;
    NSInteger totalCount = filenames.count;
    NSString *cacheDir = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject;
    
    for (NSString *filename in filenames) {
        NSString *encodedName = [filename stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        NSString *urlString = [NSString stringWithFormat:@"%@api/file/%@?filename=%@", [[YTDownloadManagerService sharedInstance] serverEndpoint], item.jobId, encodedName];
        
        [[[NSURLSession sharedSession] downloadTaskWithURL:[NSURL URLWithString:urlString] completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
            NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
            __block BOOL currentTaskFailed = NO;
            if (error || !location || (httpResponse && httpResponse.statusCode != 200)) { currentTaskFailed = YES; }
            else {
                NSURL *destURL = [NSURL fileURLWithPath:[cacheDir stringByAppendingPathComponent:filename]];
                [[NSFileManager defaultManager] removeItemAtURL:destURL error:nil];
                if ([[NSFileManager defaultManager] moveItemAtURL:location toURL:destURL error:nil]) {
                    @synchronized(localURLs) { [localURLs addObject:destURL]; }
                } else { currentTaskFailed = YES; }
            }
            
            @synchronized(self) {
                if (currentTaskFailed) subFailed = YES;
                remaining--; item.progress = (float)(totalCount - remaining) / (float)totalCount;
                [self postSafeUpdateNotification];
                if (remaining == 0) {
                    if (subFailed || localURLs.count != totalCount) { [self handleItemFailure:item isAudio:isAudio]; }
                    else {
                        item.localURLs = [localURLs copy]; item.status = YTDMQueueStatusDownloaded;
                        [self saveQueueToDisk]; [self postSafeUpdateNotification];
                        [self processNextItemInQueue:isAudio];
                    }
                }
            }
        }] resume];
    }
}

- (void)handleItemFailure:(YTDMQueueItem *)item isAudio:(BOOL)isAudio {
    item.status = YTDMQueueStatusError; item.progress = 0.0; item.jobId = nil; item.pollRetryCount = 0;
    if (item.localURLs) { for (NSURL *u in item.localURLs) [[NSFileManager defaultManager] removeItemAtURL:u error:nil]; item.localURLs = nil; }
    [self saveQueueToDisk]; [self postSafeUpdateNotification];
    [self processNextItemInQueue:isAudio];
}
@end

// ============================================================================
// QUEUE CONTROLLER USER INTERFACE (SHEET DISPLAY)
// ============================================================================
@implementation YTDMQueueSheetController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshUI) name:kYTDMQueueUpdatedNotification object:nil];
    
    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_closeButton setTitle:@"✕" forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    [_closeButton addTarget:self action:@selector(dismissSheet) forControlEvents:UIControlEventTouchUpInside];
    _closeButton.frame = CGRectMake(16, 16, 40, 40); [self.view addSubview:_closeButton];
    
    _segmentedControl = [[UISegmentedControl alloc] initWithItems:@[@"VIDEO", @"AUDIO"]];
    _segmentedControl.selectedSegmentIndex = 0;
    [_segmentedControl addTarget:self action:@selector(refreshUI) forControlEvents:UIControlEventValueChanged];
    _segmentedControl.frame = CGRectMake(70, 18, self.view.bounds.size.width - 90, 32);
    _segmentedControl.autoresizingMask = UIViewAutoresizingFlexibleWidth; [self.view addSubview:_segmentedControl];
    
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 64, self.view.bounds.size.width, self.view.bounds.size.height - 144) style:UITableViewStyleGrouped];
    _tableView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _tableView.delegate = self; _tableView.dataSource = self; _tableView.dragDelegate = self; _tableView.dropDelegate = self;
    _tableView.dragInteractionEnabled = YES; [self.view addSubview:_tableView];
    
    _downloadAllButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [_downloadAllButton setTitle:@"Download All" forState:UIControlStateNormal];
    _downloadAllButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    _downloadAllButton.backgroundColor = [UIColor systemGreenColor];
    [_downloadAllButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _downloadAllButton.layer.cornerRadius = 12;
    [_downloadAllButton addTarget:self action:@selector(downloadAllPressed) forControlEvents:UIControlEventTouchUpInside];
    _downloadAllButton.frame = CGRectMake(16, self.view.bounds.size.height - 68, self.view.bounds.size.width - 32, 44);
    _downloadAllButton.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [self.view addSubview:_downloadAllButton];
}

- (void)dismissSheet { [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)refreshUI { dispatch_async(dispatch_get_main_queue(), ^{ [self.tableView reloadData]; }); }
- (void)downloadAllPressed { [[YTDMQueueManager sharedManager] startDownloadingQueue:(_segmentedControl.selectedSegmentIndex == 1)]; }

- (NSArray<YTDMQueueItem *> *)itemsForSection:(NSInteger)section {
    NSArray *base = (_segmentedControl.selectedSegmentIndex == 1) ? [YTDMQueueManager sharedManager].audioQueue : [YTDMQueueManager sharedManager].videoQueue;
    NSMutableArray *filtered = [NSMutableArray array];
    for (YTDMQueueItem *i in base) {
        if (section == 0 && (i.status == YTDMQueueStatusPending || i.status == YTDMQueueStatusError)) [filtered addObject:i];
        if (section == 1 && (i.status == YTDMQueueStatusDownloading || i.status == YTDMQueueStatusDownloaded)) [filtered addObject:i];
    }
    return filtered;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return [self itemsForSection:section].count; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section { return (section == 0) ? @"Pending Queue" : @"Active & Downloaded Assets"; }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"YTDMQueueCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
    
    YTDMQueueItem *item = [self itemsForSection:indexPath.section][indexPath.row]; cell.textLabel.text = item.title;
    if (item.status == YTDMQueueStatusPending) {
        cell.detailTextLabel.text = item.isAudio ? @"[Audio] Ready in Queue" : [NSString stringWithFormat:@"[Video %@] Ready in Queue", item.quality ? [item.quality stringByAppendingString:@"p"] : @""];
        cell.detailTextLabel.textColor = [UIColor secondaryLabelColor];
    } else if (item.status == YTDMQueueStatusDownloading) {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"Downloading on Server... %d%%", (int)(item.progress * 100)];
        cell.detailTextLabel.textColor = [UIColor systemOrangeColor];
    } else if (item.status == YTDMQueueStatusDownloaded) {
        cell.detailTextLabel.text = @"✓ Ready (Tap to export/save)"; cell.detailTextLabel.textColor = [UIColor systemGreenColor];
    } else if (item.status == YTDMQueueStatusError) {
        cell.detailTextLabel.text = @"✗ Error - Tap to Retry"; cell.detailTextLabel.textColor = [UIColor systemRedColor];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    YTDMQueueItem *item = [self itemsForSection:indexPath.section][indexPath.row];
    if (item.status == YTDMQueueStatusError) [[YTDMQueueManager sharedManager] retryItem:item];
    else if (item.status == YTDMQueueStatusDownloaded && item.localURLs) [self presentSaveOptionsForItem:item];
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath { return indexPath.section == 0; }
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)src toIndexPath:(NSIndexPath *)dst {
    if (src.section != 0 || dst.section != 0) return;
    NSMutableArray *q = (_segmentedControl.selectedSegmentIndex == 1) ? [YTDMQueueManager sharedManager].audioQueue : [YTDMQueueManager sharedManager].videoQueue;
    NSArray *filtered = [self itemsForSection:0];
    if (src.row >= filtered.count || dst.row >= filtered.count) return;
    
    YTDMQueueItem *srcItem = filtered[src.row]; YTDMQueueItem *dstItem = filtered[dst.row];
    NSUInteger fromIdx = [q indexOfObject:srcItem];
    if (fromIdx == NSNotFound) return;
    
    [q removeObjectAtIndex:fromIdx];
    NSUInteger toIdx = [q indexOfObject:dstItem];
    if (toIdx != NSNotFound) [q insertObject:srcItem atIndex:(src.row < dst.row) ? toIdx + 1 : toIdx];
    else [q addObject:srcItem];
    [[YTDMQueueManager sharedManager] saveQueueToDisk];
}

- (NSArray<UIDragItem *> *)tableView:(UITableView *)tableView itemsForBeginningDragSession:(id<UIDragSession>)session atIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section != 0) return @[];
    YTDMQueueItem *item = [self itemsForSection:indexPath.section][indexPath.row];
    UIDragItem *drag = [[UIDragItem alloc] initWithItemProvider:[[NSItemProvider alloc] initWithObject:item.title]];
    drag.localObject = item; return @[drag];
}
- (void)tableView:(UITableView *)tableView performDropWithCoordinator:(id<UITableViewDropCoordinator>)coordinator {}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)style forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (style == UITableViewCellEditingStyleDelete) [[YTDMQueueManager sharedManager] cancelItem:[self itemsForSection:indexPath.section][indexPath.row]];
}

- (void)presentSaveOptionsForItem:(YTDMQueueItem *)item {
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"File Ready!" message:@"Where would you like to save the file?" preferredStyle:UIAlertControllerStyleActionSheet];
    if (!item.isAudio && item.localURLs.count > 0) {
        [sheet addAction:[UIAlertAction actionWithTitle:@"Save to Photos" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{ [PHAssetChangeRequest creationRequestForAssetFromVideoAtFileURL:item.localURLs.firstObject]; } completionHandler:nil];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"📁 Save to Files App" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        UIDocumentPickerViewController *p = [[UIDocumentPickerViewController alloc] initForExportingURLs:item.localURLs asCopy:YES];
        p.delegate = self; objc_setAssociatedObject(p, &kAssociatedOutURLKey, item, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        [self presentViewController:p animated:YES completion:nil];
    }]];
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:sheet animated:YES completion:nil];
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
@end

// ============================================================================
// INTERFACE CONTROLS OVERLAY HOOK & CONTEXT MENU GENERATION
// ============================================================================
@interface YTMainAppControlsOverlayView : UIView <UIDocumentPickerDelegate>
- (void)ytdm_triggerSilentDownloadWithQuality:(NSString *)quality isAudio:(BOOL)isAudio videoID:(NSString *)vidID;
- (void)ytdm_presentSaveOptionsForURLs:(NSArray<NSURL *> *)outURLs isAudio:(BOOL)isAudio;
- (void)ytdm_presentShareSheetForURLs:(NSArray<NSURL *> *)outURLs;
- (void)ytdm_playInSystemPlayer:(id)arg videoID:(NSString *)vidID;
- (void)ytdm_downloadThumbnailToPhotos:(id)arg videoID:(NSString *)vidID;
- (void)ytdm_copyToClipboardWithText:(NSString *)text alertMsg:(NSString *)alertMsg;
- (UIViewController *)ytdm_parentViewController;
@end

@interface YTMainAppVideoPlayerOverlayViewController : UIViewController
@end

@interface YTIVideoDetails : NSObject
- (NSString *)title;
- (NSString *)author;
- (NSString *)shortDescription;
@end

@interface YTIFormatStream : NSObject
- (int)itag;
- (NSString *)mimeType;
- (NSString *)qualityLabel;
@end

@interface YTIStreamingData : NSObject
- (NSArray *)adaptiveFormatsArray;
@end

@interface YTIPlayerResponse : NSObject
- (YTIVideoDetails *)videoDetails;
- (YTIStreamingData *)streamingData;
@end

@interface YTPlayerResponse : NSObject
- (YTIPlayerResponse *)playerData;
@end

@interface YTPlayerViewController : UIViewController
- (NSString *)currentVideoID;
- (CGFloat)currentVideoMediaTime;
- (YTPlayerResponse *)contentPlayerResponse;
- (YTPlayerResponse *)playerResponse;
@end

static YTIPlayerResponse *YDMIResForPlayer(YTPlayerViewController *player) {
    YTPlayerResponse *response;
    if ([player respondsToSelector:@selector(contentPlayerResponse)]) {
        response = player.contentPlayerResponse;
    } else {
        response = player.playerResponse;
    }
    return response.playerData;
}

static void YDMLoadVideoItag(YTPlayerViewController *player) {
    YTIPlayerResponse *ires = YDMIResForPlayer(player);
    YTIStreamingData *istream = ires.streamingData;
    NSArray *formatsArray = istream.adaptiveFormatsArray;
    for (YTIFormatStream *stream in formatsArray) {
        if ([stream.mimeType containsString:@"mp4"]) {
            if ([stream.mimeType containsString:@"avc1"]) {
                if ([stream.qualityLabel hasPrefix:@"1080p"]) {
                    if (!qVideo1080) stream.qualityLabel = qVideo1080;
                } else if ([stream.qualityLabel hasPrefix:@"720p"]) {
                    if (!qVideo720) stream.qualityLabel = qVideo720;
                } else if ([stream.qualityLabel hasPrefix:@"480p"]) {
                    if (!qVideo480) stream.qualityLabel = qVideo480;
                } else if ([stream.qualityLabel hasPrefix:@"360p"]) {
                    if (!qVideo360) stream.qualityLabel = qVideo360;
                } else if ([stream.qualityLabel hasPrefix:@"240p"]) {
                    if (!qVideo240) stream.qualityLabel = qVideo240;
                } else if ([stream.qualityLabel hasPrefix:@"144p"]) {
                    if (!qVideo144) stream.qualityLabel = qVideo144;
                } 
            } else if ([stream.mimeType containsString:@"mp4a"]) {
                if (!qAudio) stream.itag = [qAudio intValue];
            }
        }
    }
} 

%hook YTMainAppControlsOverlayView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIButton *downloadBtn = [self viewWithTag:9912];
    if (downloadBtn && !downloadBtn.hidden && downloadBtn.alpha > 0.01) {
        CGPoint localPoint = [downloadBtn convertPoint:point fromView:self];
        if ([downloadBtn pointInside:localPoint withEvent:event]) return downloadBtn;
    }
    return %orig;
}

- (void)layoutSubviews {
    %orig;
    UIButton *downloadBtn = [self viewWithTag:9912];
    if (!downloadBtn) {
        downloadBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        downloadBtn.tag = 9912;
        [downloadBtn setTitle:@"⬇️" forState:UIControlStateNormal];
        downloadBtn.titleLabel.font = [UIFont systemFontOfSize:14];
        downloadBtn.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.6];
        downloadBtn.layer.cornerRadius = 16;
        downloadBtn.layer.borderWidth = 0.5;
        downloadBtn.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.35].CGColor;
        downloadBtn.userInteractionEnabled = YES;
        [self addSubview:downloadBtn];
    }
    downloadBtn.frame = CGRectMake(12, 120, 32, 32);
    [self bringSubviewToFront:downloadBtn];
    
    if (@available(iOS 14.0, *)) {
        downloadBtn.showsMenuAsPrimaryAction = YES;
        __weak typeof(self) weakSelf = self;
        
        // --------------------------------------------------------------------
        // DIRECT DOWNLOAD OPTIONS
        // --------------------------------------------------------------------
        YTMainAppVideoPlayerOverlayViewController *ovcon = [self valueForKey:@"_eventsDelegate"];
        YTPlayerViewController *pvcon = (YTPlayerViewController *)ovcon.parentViewController;
        YDMLoadVideoItag(pvcon);
        NSString *vidID = pvcon.currentVideoID;
        YTIPlayerResponse *ipl = YDMIResForPlayer(pvcon);
        YTIVideoDetails *viddesc = ipl.videoDetails;
        NSString *vidti = viddesc.title;
        UIAction *v1080 = [UIAction actionWithTitle:@"Video (1080p)" image:nil identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:qVideo1080 isAudio:NO videoID:vidID]; }];
        UIAction *v720 = [UIAction actionWithTitle:@"Video (720p)" image:nil identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:qVideo720 isAudio:NO videoID:vidID]; }];
        UIAction *v480 = [UIAction actionWithTitle:@"Video (480p)" image:nil identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:qVideo480 isAudio:NO videoID:vidID]; }];
        UIAction *v360 = [UIAction actionWithTitle:@"Video (360p)" image:nil identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:qVideo360 isAudio:NO videoID:vidID]; }];
        UIAction *v240 = [UIAction actionWithTitle:@"Video (240p)" image:nil identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:qVideo240 isAudio:NO videoID:vidID]; }];
        UIAction *v144 = [UIAction actionWithTitle:@"Video (144p)" image:nil identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:qVideo144 isAudio:NO videoID:vidID]; }];
        UIMenu *videoSubmenu = [UIMenu menuWithTitle:@"Download Video" image:[UIImage systemImageNamed:@"video"] identifier:nil options:0 children:@[v1080, v720, v480, v360, v240, v144]];
        
        UIAction *audioOnly = [UIAction actionWithTitle:@"Audio Only (MP3)" image:[UIImage systemImageNamed:@"waveform"] identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_triggerSilentDownloadWithQuality:nil isAudio:YES videoID:vidID]; }];
        
        // --------------------------------------------------------------------
        // ADVANCED SMART QUEUE MANAGEMENT OPTIONS
        // --------------------------------------------------------------------
        UIAction *qAudio = [UIAction actionWithTitle:@"Add Audio to Queue" image:[UIImage systemImageNamed:@"music.note.list"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) {
                [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:nil isAudio:YES];
            }
        }];
        
        UIAction *qv1080 = [UIAction actionWithTitle:@"Queue Video (1080p)" image:[UIImage systemImageNamed:@"arrow.down.square"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:qVideo1080 isAudio:NO];
        }];
        UIAction *qv720 = [UIAction actionWithTitle:@"Queue Video (720p)" image:[UIImage systemImageNamed:@"arrow.down.square"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:qVideo720 isAudio:NO];
        }];
        UIAction *qv480 = [UIAction actionWithTitle:@"Queue Video (480p)" image:[UIImage systemImageNamed:@"arrow.down.square"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:qVideo480 isAudio:NO];
        }];
        UIAction *qv360 = [UIAction actionWithTitle:@"Queue Video (360p)" image:[UIImage systemImageNamed:@"arrow.down.square"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:qVideo360 isAudio:NO];
        }];
        UIAction *qv240 = [UIAction actionWithTitle:@"Queue Video (240p)" image:[UIImage systemImageNamed:@"arrow.down.square"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:qVideo240 isAudio:NO];
        }];
        UIAction *qv144 = [UIAction actionWithTitle:@"Queue Video (144p)" image:[UIImage systemImageNamed:@"arrow.down.square"] identifier:nil handler:^(UIAction *a) {
            if (vidID.length > 0) [[YTDMQueueManager sharedManager] addItemWithId:vidID title:vidti quality:qVideo144 isAudio:NO];
        }];
        UIMenu *queueVideoSubmenu = [UIMenu menuWithTitle:@"Add Video to Queue..." image:[UIImage systemImageNamed:@"video.badge.plus"] identifier:nil options:0 children:@[qv1080, qv720, qv480, qv360, qv240, qv144]];

        UIAction *openQueueManager = [UIAction actionWithTitle:@"Open Download Queue Manager" image:[UIImage systemImageNamed:@"list.bullet.rectangle.portrait"] identifier:nil handler:^(UIAction *a) {
            YTDMQueueSheetController *sheetVC = [[YTDMQueueSheetController alloc] init];
            sheetVC.modalPresentationStyle = UIModalPresentationPageSheet;
            [[weakSelf ytdm_parentViewController] ?: getTopMostController() presentViewController:sheetVC animated:YES completion:nil];
        }];
        
        UIMenu *queueMasterMenu = [UIMenu menuWithTitle:@"Smart Download Queue" image:[UIImage systemImageNamed:@"clock.arrow.2.circlepath"] identifier:nil options:0 children:@[qAudio, queueVideoSubmenu, openQueueManager]];
        
        // --------------------------------------------------------------------
        // SYSTEM UTILITES & METADATA COPYING
        // --------------------------------------------------------------------
        UIAction *sysPlayer = [UIAction actionWithTitle:@"Play in System Player" image:[UIImage systemImageNamed:@"arrow.up.right.video"] identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_playInSystemPlayer:nil videoID:vidID]; }];
        UIAction *dlThumb = [UIAction actionWithTitle:@"Download Thumbnail" image:[UIImage systemImageNamed:@"photo"] identifier:nil handler:^(UIAction *a) { [weakSelf ytdm_downloadThumbnailToPhotos:nil videoID:vidID]; }];
        
        UIAction *copyTitle = [UIAction actionWithTitle:@"Copy Video Title" image:[UIImage systemImageNamed:@"doc.on.clipboard"] identifier:nil handler:^(UIAction *a) {
            [weakSelf ytdm_copyToClipboardWithText:vidti alertMsg:@"Copied Title!"];
        }];
        
        UIAction *copyLink = [UIAction actionWithTitle:@"Copy Video Link" image:[UIImage systemImageNamed:@"link"] identifier:nil handler:^(UIAction *a) {
            NSString *cleanLink = vidID ? [NSString stringWithFormat:@"https://youtu.be/%@", vidID] : nil;
            NSString *formattedText = (vidti && cleanLink) ? [NSString stringWithFormat:@"%@ - %@", vidti, cleanLink] : cleanLink;
            [weakSelf ytdm_copyToClipboardWithText:formattedText alertMsg:@"Copied Link with Title!"];
        }];
        
        UIAction *copyTimestamp = [UIAction actionWithTitle:@"Copy Link with Timestamp" image:[UIImage systemImageNamed:@"clock"] identifier:nil handler:^(UIAction *a) {
            NSString *tsLink = vidID ? [NSString stringWithFormat:@"https://youtu.be/%@?t=%d", vidID, (int)pvcon.currentVideoMediaTime] : nil;
            NSString *formattedText = (vidti && tsLink) ? [NSString stringWithFormat:@"%@ - %@", vidti, tsLink] : tsLink;
            [weakSelf ytdm_copyToClipboardWithText:formattedText alertMsg:@"Copied Link with Timestamp!"];
        }];
        
        UIAction *copyDesc = [UIAction actionWithTitle:@"Copy Description" image:[UIImage systemImageNamed:@"text.justifyleft"] identifier:nil handler:^(UIAction *a) {
            [weakSelf ytdm_copyToClipboardWithText:viddesc.shortDescription alertMsg:@"Copied Description!"];
        }];
        
        UIAction *copyChannel = [UIAction actionWithTitle:@"Copy Channel Name" image:[UIImage systemImageNamed:@"person.crop.circle"] identifier:nil handler:^(UIAction *a) {
            [weakSelf ytdm_copyToClipboardWithText:viddesc.author alertMsg:@"Copied Channel!"];
        }];
        UIMenu *copySubmenu = [UIMenu menuWithTitle:@"Copy Info..." image:[UIImage systemImageNamed:@"doc.on.doc"] identifier:nil options:0 children:@[copyTitle, copyLink, copyTimestamp, copyDesc, copyChannel]];
        
        // Finalizing injection context
        downloadBtn.menu = [UIMenu menuWithTitle:@"YTDM Suite" children:@[
            videoSubmenu,
            [UIMenu menuWithTitle:@"" image:nil identifier:nil options:UIMenuOptionsDisplayInline children:@[audioOnly]],
            queueMasterMenu,
            [UIMenu menuWithTitle:@"" image:nil identifier:nil options:UIMenuOptionsDisplayInline children:@[sysPlayer, dlThumb]],
            [UIMenu menuWithTitle:@"" image:nil identifier:nil options:UIMenuOptionsDisplayInline children:@[copySubmenu]]
        ]];
    }
}

%new
- (UIViewController *)ytdm_parentViewController {
    UIResponder *responder = self;
    while ([responder nextResponder]) {
        responder = [responder nextResponder];
        if ([responder isKindOfClass:[UIViewController class]]) return (UIViewController *)responder;
    }
    return nil;
}

%new
- (void)ytdm_triggerSilentDownloadWithQuality:(NSString *)quality isAudio:(BOOL)isAudio videoID:(NSString *)vidID {
    if (vidID.length == 0) { [[YTDMProgressHUD sharedHUD] showError:@"No video detected."]; return; }
    
    [[YTDMProgressHUD sharedHUD] showInView:getKeyWindow()];
    [[YTDownloadManagerService sharedInstance] requestDownloadForVideoId:vidID isAudio:isAudio quality:quality completion:^(NSArray<NSURL *> *localURLs, NSString *errorMsg) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!localURLs) { [[YTDMProgressHUD sharedHUD] showError:errorMsg]; return; }
            [[YTDMProgressHUD sharedHUD] showSuccessWithStatus:@"Download complete!"];
            [self ytdm_presentSaveOptionsForURLs:localURLs isAudio:isAudio];
        });
    }];
}

%new
- (void)ytdm_presentSaveOptionsForURLs:(NSArray<NSURL *> *)outURLs isAudio:(BOOL)isAudio {
    UIViewController *topController = [self ytdm_parentViewController] ?: getTopMostController();
    UIAlertController *actionSheet = [UIAlertController alertControllerWithTitle:@"File Ready!" message:@"Where would you like to save the file?" preferredStyle:UIAlertControllerStyleActionSheet];
    
    if (!isAudio) {
        NSURL *outURL = outURLs.firstObject;
        UIAlertAction *saveToPhotos = [UIAlertAction actionWithTitle:@"Save to Photos (Camera Roll)" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
            [[YTDMProgressHUD sharedHUD] showInView:getKeyWindow()];
            [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
                [PHAssetChangeRequest creationRequestForAssetFromVideoAtFileURL:outURL];
            } completionHandler:^(BOOL success, NSError *err) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (success) [[YTDMProgressHUD sharedHUD] showSuccessWithStatus:@"Saved to Gallery!"];
                    else [[YTDMProgressHUD sharedHUD] showError:@"Gallery save failed."];
                    [[NSFileManager defaultManager] removeItemAtURL:outURL error:nil];
                });
            }];
        }];
        [actionSheet addAction:saveToPhotos];
    }
    
    UIAlertAction *saveToFiles = [UIAlertAction actionWithTitle:@"📁 Save to Files App" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        if (@available(iOS 14.0, *)) {
            UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForExportingURLs:outURLs asCopy:YES];
            picker.delegate = (id<UIDocumentPickerDelegate>)self;
            objc_setAssociatedObject(picker, &kAssociatedOutURLKey, outURLs, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [topController presentViewController:picker animated:YES completion:nil];
        } else {
            [self ytdm_presentShareSheetForURLs:outURLs];
        }
    }];
    [actionSheet addAction:saveToFiles];
    
    UIAlertAction *openShare = [UIAlertAction actionWithTitle:@"📤 Open Share Sheet" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) { [self ytdm_presentShareSheetForURLs:outURLs]; }];
    [actionSheet addAction:openShare];
    
    UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:^(UIAlertAction *a) {
        for (NSURL *url in outURLs) [[NSFileManager defaultManager] removeItemAtURL:url error:nil];
    }];
    [actionSheet addAction:cancel];
    
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        UIButton *btn = [self viewWithTag:9912];
        actionSheet.popoverPresentationController.sourceView = btn ?: topController.view;
        actionSheet.popoverPresentationController.sourceRect = btn ? btn.bounds : topController.view.bounds;
    }
    [topController presentViewController:actionSheet animated:YES completion:nil];
}

%new
- (void)ytdm_presentShareSheetForURLs:(NSArray<NSURL *> *)outURLs {
    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:outURLs applicationActivities:nil];
    share.completionWithItemsHandler = ^(UIActivityType actType, BOOL completed, NSArray *retItems, NSError *err) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            for (NSURL *url in outURLs) [[NSFileManager defaultManager] removeItemAtURL:url error:nil];
        });
    };
    if ([UIDevice currentDevice].userInterfaceIdiom == UIUserInterfaceIdiomPad) {
        UIButton *btn = [self viewWithTag:9912];
        share.popoverPresentationController.sourceView = btn ?: getTopMostController().view;
        share.popoverPresentationController.sourceRect = btn ? btn.bounds : getTopMostController().view.bounds;
    }
    [[self ytdm_parentViewController] ?: getTopMostController() presentViewController:share animated:YES completion:nil];
}

%new
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSArray<NSURL *> *outURLs = objc_getAssociatedObject(controller, &kAssociatedOutURLKey);
    if (outURLs) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            for (NSURL *url in outURLs) [[NSFileManager defaultManager] removeItemAtURL:url error:nil];
        });
    }
}

%new
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    NSArray<NSURL *> *outURLs = objc_getAssociatedObject(controller, &kAssociatedOutURLKey);
    if (outURLs) { for (NSURL *url in outURLs) [[NSFileManager defaultManager] removeItemAtURL:url error:nil]; }
}

%new
- (void)ytdm_playInSystemPlayer:(id)arg videoID:(NSString *)vidID {
    if (vidID.length == 0) {
        dispatch_async(dispatch_get_main_queue(), ^{ [[YTDMProgressHUD sharedHUD] showError:@"No video detected."]; });
        return;
    }
    
    [[YTDMProgressHUD sharedHUD] showInView:getKeyWindow()];
    [[YTDownloadManagerService sharedInstance] requestStreamURLForVideoId:vidID completion:^(NSString *streamURL, NSString *errorMsg) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!streamURL) { [[YTDMProgressHUD sharedHUD] showError:errorMsg]; return; }
            [[YTDMProgressHUD sharedHUD] showSuccessWithStatus:@"Playing..."];
            
            AVPlayer *p = [AVPlayer playerWithURL:[NSURL URLWithString:streamURL]];
            AVPlayerViewController *vc = [[AVPlayerViewController alloc] init];
            vc.player = p; vc.entersFullScreenWhenPlaybackBegins = YES;
            vc.allowsPictureInPicturePlayback = YES;
            
            UIViewController *topController = [self ytdm_parentViewController] ?: getTopMostController();
            [topController presentViewController:vc animated:YES completion:^{ [p play]; }];
        });
    }];
}

%new
- (void)ytdm_downloadThumbnailToPhotos:(id)arg videoID:(NSString *)vidID {
    if (vidID.length == 0) return;
    [[YTDMProgressHUD sharedHUD] showInView:getKeyWindow()];
    NSString *url = [NSString stringWithFormat:@"https://img.youtube.com/vi/%@/hqdefault.jpg", vidID];
    [[[NSURLSession sharedSession] dataTaskWithURL:[NSURL URLWithString:url] completionHandler:^(NSData *d, NSURLResponse *r, NSError *e) {
        UIImage *img = [UIImage imageWithData:d];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (img) {
                [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{ [PHAssetChangeRequest creationRequestForAssetFromImage:img]; } completionHandler:^(BOOL s, NSError *err) {
                    dispatch_async(dispatch_get_main_queue(), ^{ if (s) [[YTDMProgressHUD sharedHUD] showSuccessWithStatus:@"Saved Thumbnail!"]; else [[YTDMProgressHUD sharedHUD] showError:@"Save failed."]; });
                }];
            } else { [[YTDMProgressHUD sharedHUD] showError:@"Not found."]; }
        });
    }] resume];
}

%new
- (void)ytdm_copyToClipboardWithText:(NSString *)text alertMsg:(NSString *)alertMsg {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (text && text.length > 0) {
            [UIPasteboard generalPasteboard].string = text;
            [[YTDMProgressHUD sharedHUD] showSuccessWithStatus:alertMsg];
        } else { [[YTDMProgressHUD sharedHUD] showError:@"Metadata unavailable."]; }
    });
}
%end

// ============================================================================
// ATS BYPASS
// ============================================================================
%hook NSBundle
- (NSDictionary *)infoDictionary {
    NSDictionary *origDict = %orig;
    if (origDict) {
        if (origDict[@"NSAppTransportSecurity"] && [origDict[@"NSAppTransportSecurity"][@"NSAllowsArbitraryLoads"] boolValue]) { return origDict; }
        NSMutableDictionary *m = [origDict mutableCopy];
        NSMutableDictionary *ats = [m[@"NSAppTransportSecurity"] mutableCopy] ?: [NSMutableDictionary dictionary];
        ats[@"NSAllowsArbitraryLoads"] = @YES; m[@"NSAppTransportSecurity"] = ats;
        return m;
    }
    return origDict;
}
%end